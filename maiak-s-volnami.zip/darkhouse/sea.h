#pragma once
#include <vector>
#include <glad/glad.h>
#include "waves.h"

class Sea {
public:
    Sea(int cells, float size) : cells(cells), size(size), step(size / cells) {
        int n = cells + 1;
        positions.resize((size_t)n * n * 3);
        normals.resize((size_t)n * n * 3);
        colors.resize((size_t)n * n * 3);
        for (int j = 0; j < cells; j++) {
            for (int i = 0; i < cells; i++) {
                unsigned int a = j * n + i;
                unsigned int b = a + 1;
                unsigned int c = a + n;
                unsigned int d = c + 1;
                indices.push_back(a);
                indices.push_back(c);
                indices.push_back(b);
                indices.push_back(b);
                indices.push_back(c);
                indices.push_back(d);
            }
        }
    }

    void update(float t, float centerX, float centerZ) {
        float ox = std::floor(centerX / step) * step;
        float oz = std::floor(centerZ / step) * step;
        int n = cells + 1;
        float amp = Waves::params().amplitude;
        for (int j = 0; j < n; j++) {
            for (int i = 0; i < n; i++) {
                float x = ox - size / 2.0f + i * step;
                float z = oz - size / 2.0f + j * step;
                Vec3 p;
                Vec3 nrm;
                Waves::evaluate(x, z, t, p, nrm);
                size_t k = ((size_t)j * n + i) * 3;
                positions[k] = p.x;
                positions[k + 1] = p.y;
                positions[k + 2] = p.z;
                normals[k] = nrm.x;
                normals[k + 1] = nrm.y;
                normals[k + 2] = nrm.z;
                float foam = smoothstep(0.55f, 0.95f, p.y / amp) * 0.8f;
                colors[k] = 0.08f + (0.75f - 0.08f) * foam;
                colors[k + 1] = 0.18f + (0.82f - 0.18f) * foam;
                colors[k + 2] = 0.28f + (0.85f - 0.28f) * foam;
            }
        }
    }

    void draw() const {
        glEnableClientState(GL_VERTEX_ARRAY);
        glEnableClientState(GL_NORMAL_ARRAY);
        glEnableClientState(GL_COLOR_ARRAY);
        glVertexPointer(3, GL_FLOAT, 0, positions.data());
        glNormalPointer(GL_FLOAT, 0, normals.data());
        glColorPointer(3, GL_FLOAT, 0, colors.data());
        glDrawElements(GL_TRIANGLES, (GLsizei)indices.size(), GL_UNSIGNED_INT, indices.data());
        glDisableClientState(GL_COLOR_ARRAY);
        glDisableClientState(GL_NORMAL_ARRAY);
        glDisableClientState(GL_VERTEX_ARRAY);
    }

private:
    int cells;
    float size;
    float step;
    std::vector<float> positions;
    std::vector<float> normals;
    std::vector<float> colors;
    std::vector<unsigned int> indices;
};
