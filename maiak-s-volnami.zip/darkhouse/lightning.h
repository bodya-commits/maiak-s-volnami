#pragma once
#include <glad/glad.h>
#include "vec.h"

class Lightning {
public:
    static const int POINTS = 14;

    float flash = 0.0f;
    float age = 100.0f;
    Vec3 direction{0.0f, 1.0f, 0.0f};

    void update(float t, Vec3 camera) {
        if (t >= nextFlash) {
            start = t;
            nextFlash = t + 2.5f + rnd01() * 6.0f;
            spawn(camera);
        }
        age = t - start;
        flash = 0.0f;
        if (age >= 0.0f && age < 1.5f) {
            flash = std::exp(-age * 9.0f);
            if (age > 0.18f) {
                float second = 0.8f * std::exp(-(age - 0.18f) * 11.0f);
                flash = flash > second ? flash : second;
            }
        }
    }

    bool boltVisible() const {
        return age < 0.4f && flash > 0.05f;
    }

    void drawBolt() const {
        float k = 0.4f + 0.6f * flash;
        glColor4f(0.85f * k, 0.9f * k, 1.0f * k, 1.0f);
        glBegin(GL_TRIANGLE_STRIP);
        for (int i = 0; i < POINTS * 2; i++) {
            glVertex3f(bolt[i].x, bolt[i].y, bolt[i].z);
        }
        glEnd();
    }

private:
    float start = -100.0f;
    float nextFlash = 3.0f;
    Vec3 bolt[POINTS * 2];

    void spawn(Vec3 camera) {
        float a = rnd01() * 2.0f * PI;
        float r = 70.0f + rnd01() * 50.0f;
        float x = std::cos(a) * r;
        float z = std::sin(a) * r;
        direction = normalize({x, 40.0f, z});
        Vec3 toCam = normalize({camera.x - x, 0.0f, camera.z - z});
        Vec3 side = normalize(cross({0.0f, 1.0f, 0.0f}, toCam)) * 0.4f;
        float px = x;
        float pz = z;
        for (int i = 0; i < POINTS; i++) {
            float y = 80.0f * (1.0f - i / (float)(POINTS - 1));
            bolt[i * 2] = {px - side.x, y, pz - side.z};
            bolt[i * 2 + 1] = {px + side.x, y, pz + side.z};
            px += (rnd01() - 0.5f) * 6.0f;
            pz += (rnd01() - 0.5f) * 6.0f;
        }
    }
};
