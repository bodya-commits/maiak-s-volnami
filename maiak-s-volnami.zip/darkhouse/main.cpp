#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

#include "vec.h"
#include "waves.h"
#include "sea.h"
#include "rocks.h"
#include "lighthouse.h"
#include "model.h"
#include "lightning.h"

int windowWidth = 1280;
int windowHeight = 720;

float camX = 0.0f;
float camY = 9.0f;
float camZ = 58.0f;
float camYaw = -90.0f;
float camPitch = 8.0f;

bool dragging = false;
double lastX = 0.0;
double lastY = 0.0;

Vec3 cameraDirection() {
    float y = camYaw * PI / 180.0f;
    float p = camPitch * PI / 180.0f;
    return {std::cos(y) * std::cos(p), std::sin(p), std::sin(y) * std::cos(p)};
}

void moveCamera(float amount) {
    Vec3 d = cameraDirection();
    camX += d.x * amount;
    camY += d.y * amount;
    camZ += d.z * amount;
    if (camY < 2.5f) {
        camY = 2.5f;
    }
}

void rotateCamera(float dYaw, float dPitch) {
    camYaw += dYaw;
    camPitch += dPitch;
    if (camPitch > 85.0f) camPitch = 85.0f;
    if (camPitch < -85.0f) camPitch = -85.0f;
}

void framebufferSizeCallback(GLFWwindow* window, int w, int h) {
    windowWidth = w;
    windowHeight = h;
    glViewport(0, 0, w, h);
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {
    if (button == GLFW_MOUSE_BUTTON_LEFT) {
        dragging = (action == GLFW_PRESS);
        glfwGetCursorPos(window, &lastX, &lastY);
    }
}

void cursorPosCallback(GLFWwindow* window, double x, double y) {
    if (dragging) {
        rotateCamera((float)(x - lastX) * 0.2f, (float)(lastY - y) * 0.2f);
    }
    lastX = x;
    lastY = y;
}

void scrollCallback(GLFWwindow* window, double dx, double dy) {
    moveCamera((float)dy * 4.0f);
}

void handleKeys(GLFWwindow* window, float dt) {
    float boost = glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS ? 3.0f : 1.0f;
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) rotateCamera(-60.0f * dt, 0.0f);
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) rotateCamera(60.0f * dt, 0.0f);
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) moveCamera(20.0f * boost * dt);
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) moveCamera(-20.0f * boost * dt);
    if (glfwGetKey(window, GLFW_KEY_PAGE_UP) == GLFW_PRESS) rotateCamera(0.0f, 40.0f * dt);
    if (glfwGetKey(window, GLFW_KEY_PAGE_DOWN) == GLFW_PRESS) rotateCamera(0.0f, -40.0f * dt);
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) glfwSetWindowShouldClose(window, GLFW_TRUE);
}

void setupLights() {
    GLfloat spotDiffuse[4] = {3.5f, 3.2f, 2.5f, 1.0f};
    GLfloat spotAmbient[4] = {0.0f, 0.0f, 0.0f, 1.0f};
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT0, GL_AMBIENT, spotAmbient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, spotDiffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, spotDiffuse);
    glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 14.0f);
    glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 40.0f);
    glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0f);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.01f);
    glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.0004f);
    glLightfv(GL_LIGHT1, GL_AMBIENT, spotAmbient);
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
    glEnable(GL_NORMALIZE);
}

void setMaterial(float spec, float shininess) {
    GLfloat s[4] = {spec, spec, spec, 1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, s);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
}

void applyProjection() {
    float aspect = (float)windowWidth / (float)windowHeight;
    float nearPlane = 0.1f;
    float farPlane = 500.0f;
    float top = nearPlane * std::tan(30.0f * PI / 180.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-top * aspect, top * aspect, -top, top, nearPlane, farPlane);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glRotatef(-camPitch, 1.0f, 0.0f, 0.0f);
    glRotatef(camYaw + 90.0f, 0.0f, 1.0f, 0.0f);
    glTranslatef(-camX, -camY, -camZ);
}

void drawBoat(const Model& boat, float t) {
    float yaw = 2.3f;
    float fx = std::sin(yaw);
    float fz = std::cos(yaw);
    float rx = std::cos(yaw);
    float rz = -std::sin(yaw);
    float bx = 16.0f;
    float bz = 18.0f;

    Vec3 bow = Waves::sample(bx + fx * 3.2f, bz + fz * 3.2f, t);
    Vec3 stern = Waves::sample(bx - fx * 2.6f, bz - fz * 2.6f, t);
    Vec3 left = Waves::sample(bx - rx * 1.1f, bz - rz * 1.1f, t);
    Vec3 right = Waves::sample(bx + rx * 1.1f, bz + rz * 1.1f, t);
    Vec3 center = Waves::sample(bx, bz, t);

    Vec3 along = bow - stern;
    Vec3 across = right - left;
    Vec3 up = normalize(cross(along, across));
    Vec3 forward = normalize(along);
    Vec3 side = normalize(cross(up, forward));
    forward = normalize(cross(side, up));
    float y = (bow.y + stern.y + left.y + right.y) * 0.25f;

    GLfloat m[16] = {
        side.x, side.y, side.z, 0.0f,
        up.x, up.y, up.z, 0.0f,
        forward.x, forward.y, forward.z, 0.0f,
        center.x, y, center.z, 1.0f
    };
    glPushMatrix();
    glMultMatrixf(m);
    boat.draw();
    glPopMatrix();
}

int main() {
    std::srand((unsigned int)std::time(NULL));

    glfwInit();

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
    glfwWindowHint(GLFW_SAMPLES, 4);

    GLFWwindow* window = glfwCreateWindow(windowWidth, windowHeight, "Darkhouse", NULL, NULL);
    if (window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);
    glfwSetMouseButtonCallback(window, mouseButtonCallback);
    glfwSetCursorPosCallback(window, cursorPosCallback);
    glfwSetScrollCallback(window, scrollCallback);
    glfwGetFramebufferSize(window, &windowWidth, &windowHeight);
    glViewport(0, 0, windowWidth, windowHeight);

    Model boat;
    if (!boat.load("boat.obj") && !boat.load("../boat.obj") && !boat.load("../../boat.obj")) {
        std::cout << "Failed to load boat.obj (put it next to the executable or into the working directory)" << std::endl;
        glfwTerminate();
        return -1;
    }

    Sea sea(120, 200.0f);
    Rocks rocks;
    Lightning lightning;

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);
    setupLights();

    float previous = (float)glfwGetTime();

    while (!glfwWindowShouldClose(window)) {
        float t = (float)glfwGetTime();
        float dt = t - previous;
        previous = t;

        handleKeys(window, dt);

        Vec3 camPos = {camX, camY, camZ};
        lightning.update(t, camPos);
        float flash = lightning.flash;

        float spotAngle = t * 0.9f;
        float tilt = 0.18f;
        Vec3 spotDir = {std::cos(spotAngle) * std::cos(tilt), -std::sin(tilt), std::sin(spotAngle) * std::cos(tilt)};

        GLfloat fogColor[4] = {0.055f + 0.45f * flash, 0.075f + 0.5f * flash, 0.115f + 0.6f * flash, 1.0f};
        GLfloat ambient[4] = {0.12f + 0.2f * flash, 0.15f + 0.22f * flash, 0.22f + 0.25f * flash, 1.0f};
        GLfloat flashDiffuse[4] = {0.14f + 0.9f * flash, 0.18f + 1.0f * flash, 0.28f + 1.2f * flash, 1.0f};

        glClearColor(fogColor[0], fogColor[1], fogColor[2], 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        applyProjection();

        GLfloat spotPos[4] = {0.0f, Lighthouse::LANTERN_Y, 0.0f, 1.0f};
        GLfloat spotDirection[3] = {spotDir.x, spotDir.y, spotDir.z};
        glLightfv(GL_LIGHT0, GL_POSITION, spotPos);
        glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spotDirection);
        GLfloat flashPos[4] = {-0.4f, 0.5f, -0.7f, 0.0f};
        if (flash > 0.02f) {
            flashPos[0] = lightning.direction.x;
            flashPos[1] = lightning.direction.y;
            flashPos[2] = lightning.direction.z;
        }
        glLightfv(GL_LIGHT1, GL_POSITION, flashPos);
        glLightfv(GL_LIGHT1, GL_DIFFUSE, flashDiffuse);
        glLightfv(GL_LIGHT1, GL_SPECULAR, flashDiffuse);
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);

        glEnable(GL_FOG);
        glFogi(GL_FOG_MODE, GL_EXP2);
        glFogf(GL_FOG_DENSITY, 0.016f);
        glFogfv(GL_FOG_COLOR, fogColor);
        glHint(GL_FOG_HINT, GL_NICEST);

        glEnable(GL_LIGHTING);
        setMaterial(0.8f, 80.0f);
        sea.update(t, camX, camZ);
        sea.draw();

        setMaterial(0.1f, 10.0f);
        rocks.draw();
        Lighthouse::drawBody();

        setMaterial(0.25f, 30.0f);
        drawBoat(boat, t);

        glDisable(GL_LIGHTING);
        Lighthouse::drawLantern();

        glDisable(GL_FOG);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        glDepthMask(GL_FALSE);

        for (int i = 0; i < 12; i++) {
            float scale = 1.0f - i * 0.08f;
            glPushMatrix();
            glTranslatef(0.0f, Lighthouse::LANTERN_Y, 0.0f);
            glRotatef(-spotAngle * 180.0f / PI, 0.0f, 1.0f, 0.0f);
            glRotatef(-tilt * 180.0f / PI, 0.0f, 0.0f, 1.0f);
            glScalef(1.0f, scale, scale);
            Lighthouse::drawBeam(100.0f, 21.0f, 40);
            glPopMatrix();
        }

        if (lightning.boltVisible()) {
            lightning.drawBolt();
        }

        glDepthMask(GL_TRUE);
        glDisable(GL_BLEND);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
