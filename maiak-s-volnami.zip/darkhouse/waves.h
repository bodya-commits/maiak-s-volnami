#pragma once
#include <cmath>
#include "vec.h"

namespace Waves {

const int COUNT = 4;
const float STEEPNESS = 0.75f;
const float GRAVITY = 9.81f;

const float DATA[COUNT][4] = {
    {1.0f, 0.2f, 1.00f, 36.0f},
    {0.7f, 0.7f, 0.60f, 21.0f},
    {-0.3f, 1.0f, 0.35f, 13.0f},
    {0.9f, -0.5f, 0.18f, 8.0f}
};

struct Params {
    float dx[COUNT];
    float dz[COUNT];
    float k[COUNT];
    float w[COUNT];
    float q[COUNT];
    float amplitude;

    Params() {
        amplitude = 0.0f;
        for (int i = 0; i < COUNT; i++) {
            float len = std::sqrt(DATA[i][0] * DATA[i][0] + DATA[i][1] * DATA[i][1]);
            dx[i] = DATA[i][0] / len;
            dz[i] = DATA[i][1] / len;
            k[i] = 2.0f * PI / DATA[i][3];
            w[i] = std::sqrt(GRAVITY * k[i]);
            q[i] = STEEPNESS / (k[i] * DATA[i][2] * COUNT);
            amplitude += DATA[i][2];
        }
    }
};

inline const Params& params() {
    static Params p;
    return p;
}

inline void evaluate(float x, float z, float t, Vec3& pos, Vec3& normal) {
    const Params& p = params();
    float px = x;
    float py = 0.0f;
    float pz = z;
    float nx = 0.0f;
    float ny = 0.0f;
    float nz = 0.0f;
    for (int i = 0; i < COUNT; i++) {
        float a = DATA[i][2];
        float phase = p.k[i] * (p.dx[i] * x + p.dz[i] * z) - p.w[i] * t;
        float c = std::cos(phase);
        float s = std::sin(phase);
        px += p.q[i] * a * p.dx[i] * c;
        pz += p.q[i] * a * p.dz[i] * c;
        py += a * s;
        nx -= p.dx[i] * p.k[i] * a * c;
        nz -= p.dz[i] * p.k[i] * a * c;
        ny -= p.q[i] * p.k[i] * a * s;
    }
    pos = {px, py, pz};
    normal = normalize({nx, 1.0f + ny, nz});
}

inline Vec3 sample(float targetX, float targetZ, float t) {
    float x = targetX;
    float z = targetZ;
    Vec3 p;
    Vec3 n;
    for (int i = 0; i < 4; i++) {
        evaluate(x, z, t, p, n);
        x += targetX - p.x;
        z += targetZ - p.z;
    }
    evaluate(x, z, t, p, n);
    return p;
}

}
